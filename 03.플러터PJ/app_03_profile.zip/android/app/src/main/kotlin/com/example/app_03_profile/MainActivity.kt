package com.example.app_03_profile

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
